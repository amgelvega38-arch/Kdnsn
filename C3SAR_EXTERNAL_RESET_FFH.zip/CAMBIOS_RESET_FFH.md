# RESET FFH

- Se agregó una pestaña RESET FFH al panel C3SAR EXTERNAL.
- El interruptor usa el paquete Reset Guest.3105 suministrado.
- Activar aplica el cambio y desactivar restaura los archivos respaldados por el motor de patches.
- El paquete apunta al bundle `com.dts.freefireth` (Free Fire), no a Free Fire MAX.
- Cierra el juego antes de aplicar o restaurar el cambio.
